Fixture report bundle (tests/fixtures/beta). Rows hold numbers, enums and hashed ids only.
